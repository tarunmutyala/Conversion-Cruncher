# Structure Diagrams

## Added all the implemented Structure Diagrams here.
* [Composite Structure Diagram](https://github.com/28-shravya/stepin_project/blob/main/2_Architecture/structure%20Diagrams/Composite%20Diagram.png)
* [Component Diagram](https://github.com/28-shravya/stepin_project/blob/main/2_Architecture/structure%20Diagrams/Component%20diagram.png)
