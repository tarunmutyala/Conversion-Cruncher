# Architecture

* Added structural and behavior UML Diagrams in the respected folders.
