# Behavior Diagrams

## Added the implememted Behavior diagrams here. 
* [Activity diagram](https://github.com/28-shravya/stepin_project/blob/main/2_Architecture/behavior%20Diagrams/UseCase.png)
* [Use case diagram](https://github.com/28-shravya/stepin_project/blob/main/2_Architecture/behavior%20Diagrams/activity%20diagram.png)
