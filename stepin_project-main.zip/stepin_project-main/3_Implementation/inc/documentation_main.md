@mainpage Calculator Operations with different modes by Shravya K N 

@subpage calculator_operations.h
